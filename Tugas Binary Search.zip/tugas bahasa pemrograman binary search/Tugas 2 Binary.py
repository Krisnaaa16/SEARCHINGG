def binary_search(arr, x):
    # Inisialisasi batas bawah dan atas
    low = 0
    high = len(arr) - 1
    
    while low <= high:
        mid = (low + high) // 2  # Menentukan titik tengah
        
        # Memeriksa apakah x berada di tengah
        if arr[mid] == x:
            return mid  # Mengembalikan indeks jika ditemukan
        
        # Jika x lebih besar, cari di sebelah kanan
        elif arr[mid] < x:
            low = mid + 1
        
        # Jika x lebih kecil, cari di sebelah kiri
        else:
            high = mid - 1
    
    return -1  # Mengembalikan -1 jika tidak ditemukan

# Contoh penggunaan
data = [2, 4, 6, 8, 10, 12, 14, 16, 18, 20]
cari = 12

hasil = binary_search(data, cari)

if hasil != -1:
    print(f"Angka {cari} ditemukan di indeks ke-{hasil}.")
else:
    print(f"Angka {cari} tidak ditemukan dalam list.")